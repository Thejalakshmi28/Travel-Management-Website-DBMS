<?php
$start=$_POST['start'];
$end=$_POST['pend'];
$day=$_POST['day'];
$num=$_POST['num'];
$bus=$_POST['busn'];

include("connection.php");
session_start();

 
$sql2="SELECT `noofbooked`,`noofseats` from `bus` where `busname`='$bus'";
 $result2=mysqli_query($conn,$sql2);
 $result2=mysqli_fetch_assoc($result2);
 $seats=$result2['noofseats'];
 $book=$result2['noofbooked'];
 if($book>=$seats)
 	echo '<script>alert("Sorry!\nNo more seats available in '.$bus.'")
window.location.href="index.php"
        </script>';
$sql1="UPDATE `bus` SET  `noofbooked`=`noofbooked`+'$num' WHERE `busname`='$bus'";
$result1=mysqli_query($conn,$sql1);
$booked=$book+$num;
$book=$book+1;


// $sql="INSERT INTO `busdetails`(`start`, `end`,`busname`, `day`, `num`) VALUES('$start','$end','$bus',  '$day','$num')";
// $result3=mysqli_query($conn,$sql);
// if($result)
// {
 	
 	
 	$sql="SELECT btime from busplace where pid=(SELECT pid from places where pname='$start' ) and bid=(SELECT busid from bus where busname='$bus' )";
 	$result1=mysqli_query($conn,$sql);
 	$result1=mysqli_fetch_assoc($result1);

 	$ttime=$result1['btime'];
 	$sql2="SELECT price from busprice where pfrom='$start' and pto='$end'";
 	$result2=mysqli_query($conn,$sql2);
 	$result2=mysqli_fetch_assoc($result2);
 	$sum=$num*$result2['price'];
 	// $sum=bcmul($num,$result2);
 	$sql="INSERT INTO `busdetails`(`start`, `end`,`busname`, `day`, `num`,`price`,`uid`) VALUES('$start','$end','$bus',  '$day','$num',$sum,".$_SESSION['userid'].")";
 	// $sql="INSERT INTO `busdetails`(`price`) VALUES($sum)";
 	$result=mysqli_query($conn,$sql);
 	if($result)
{
	if($num>1)
	{
	
	echo '<script type="text/javascript"> 
	let price= 
	alert("You have to pay Rs. '.$sum.'\nYour bus arrives '.$start.' at '.$ttime.'\nYour seat numbers are from '.$book.' to '.$booked.' ")
window.location.href="index.php"
        </script>';
    }
    else
    {
    	echo '<script type="text/javascript"> 
	let price= 
	alert("You have to pay Rs. '.$sum.'\nYour bus arrives '.$start.' at '.$ttime.'\nYour seat number is '.$book.' ")
window.location.href="index.php"
        </script>';

    }
} 	  
// }
// else
// {
// 	  echo '<script>alert("Sorry!\nCouldnt book your bus seats.")
// window.location.href="index.html"
//         </script>';
// }
?>