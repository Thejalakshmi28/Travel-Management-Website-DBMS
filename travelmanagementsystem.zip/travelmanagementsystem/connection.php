<?php
  
$servername = "localhost";
$username = "root";
$password = "";
$dbname ="travelmanagement";
  
// Create connection
$conn =mysqli_connect($servername, $username, $password, $dbname);
  
// Check connection
if (!$conn) 
{
    echo "Db connection error";
    die("Connection failed: db conenction error");
}

?>