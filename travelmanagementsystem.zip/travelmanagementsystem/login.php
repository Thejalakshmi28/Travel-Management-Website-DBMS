<?php
$email=$_POST['email'];
$pswd=$_POST['password'];

include("connection.php");
$sql="SELECT * FROM login WHERE uemail='".$email."' AND upassword='".$pswd."'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result))
{
	session_start();

 	$_SESSION['userid']=mysqli_fetch_assoc($result)['uid'];
 	  echo '<script>alert("You are Logged in")
window.location.href="index.php"
        </script>';
    //echo " You Have Successfully Logged in";
	//header("loaction:./home.html");
}
else
{
	  echo '<script>alert("Invalid username/password!\nEnter valid username and password")
window.location.href="loginn.html"
        </script>';
}
?>