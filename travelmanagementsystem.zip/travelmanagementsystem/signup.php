<?php
$email=$_POST['email'];
$cpswd=$_POST['cpass'];
$pswd=$_POST['password'];
$name=$_POST['name'];

include("connection.php");
if($pswd==$cpswd){
$sql="INSERT INTO `login`(`uname`, `uemail`, `upassword`) VALUES ('$name','$email','$pswd')";
$result=mysqli_query($conn,$sql);
//$row=mysqli_num_rows($result);
if($result)
{
    
        // echo "Message";
        echo '<script>alert("New Account Created\nWelcome to Travel Management System")
window.location.href="index.php"
        </script>';
    }
    else
    {
    	echo '<script>alert("Couldnt Create an Account\nTry Again!")
window.location.href="loginn.html"
        </script>';
    }
}
else{
	echo '<script>alert("Passwords dont match")
        </script>';
}
?>