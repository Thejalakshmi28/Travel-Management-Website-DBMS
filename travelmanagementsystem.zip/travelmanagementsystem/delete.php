<?php
include("connection.php");
session_start();

if(!$_SESSION['userid']){
	header('Location:login.html');
}

$sq="SELECT  `num`,`busname` from `busdetails` where `bdid`=".$_GET['id'];
$result4=mysqli_query($conn,$sq);
$result4=mysqli_fetch_assoc($result4);
$num=$result4['num'];
$busn=$result4['busname'];

$sqll="UPDATE `bus` set `noofbooked`=`noofbooked`-'$num' where `busname`='$busn' ";
$result4=mysqli_query($conn,$sqll);




$sql="DELETE FROM `busdetails` WHERE `bdid`=".$_GET['id'];
if(mysqli_query($conn,$sql)){
    echo "<script>
    alert('Deleted your Booking.Thank you')
    window.location.href='view.php'
    </script>"
    ;
}


?>